labkey.insertRows <- function(baseUrl, folderPath, schemaName, queryName, toInsert, stripAllHidden=TRUE)
{  
## Default showAllRows=TRUE
showAllRows=TRUE

## Error if any of baseUrl, folderPath, schemName or toInsert are missing
if(exists("baseUrl")==FALSE || exists("folderPath")==FALSE || exists("schemaName")==FALSE || exists("toInsert")==FALSE)
stop (paste("A value must be specified for each of baseUrl, folderPath, schemaName and toInsert."))

## Formatting
baseUrl <- gsub("[\\]", "/", baseUrl)
folderPath <- gsub("[\\]", "/", folderPath)
if(substr(baseUrl, nchar(baseUrl), nchar(baseUrl))!="/"){baseUrl <- paste(baseUrl,"/",sep="")}
if(substr(folderPath, nchar(folderPath), nchar(folderPath))!="/"){folderPath <- paste(folderPath,"/",sep="")}
if(substr(folderPath, 1, 1)!="/"){folderPath <- paste("/",folderPath,sep="")}

## URL encode folder path, JSON encode post body
if(length(grep("%",folderPath))<1) {folderPath <- URLencode(folderPath)}
pbody <- toJSON(list(schemaName=schemaName, queryName=queryName, rows=toInsert))


## Set options
reader <- basicTextGatherer()
header <- basicTextGatherer()
handle <- getCurlHandle()
headerFields <- c('Content-Type'="application/json;charset=utf-8")
if(exists("labkey.sessionCookieName")==FALSE) 
{myopts <- curlOptions(netrc=1, writefunction=reader$update, headerfunction=header$update, ssl.verifyhost=FALSE, 
						ssl.verifypeer=FALSE, followlocation=TRUE)} else
{myopts <- curlOptions(cookie=paste(labkey.sessionCookieName,"=",labkey.sessionCookieContents,sep=""), 
						writefunction=reader$update, headerfunction=header$update, ssl.verifyhost=FALSE, 
						ssl.verifypeer=FALSE, followlocation=TRUE)}


## Post form
myurl <- paste(baseUrl,"query",folderPath,"insertRows.api",sep="")
curlPerform(url=myurl, postFields=pbody, httpheader=headerFields, .opts=myopts, curl=handle)
#postForm(uri=myurl, "schemaName"=schemaName, "queryName"=queryName, "rows"=updates, .opts=myopts, curl=handle)


## Error checking for incoming file
h <- parseHeader(header$value())
status <- getCurlInfo(handle)$response.code
message <- h$statusMessage
if(status==500) {decode <- fromJSON(reader$value()); message <- decode$exception; stop(paste("HTTP request was unsuccessful. Status code = ",status,", Error message = ",message,sep=""))}
if(status>=400) stop (paste("HTTP request was unsuccessful. Status code = ",status,", Error message = ",message,". Please check the spelling of the input variables.",sep="")) else{newdata <- makeDF(reader$value(), stripAllHidden)}

return(newdata)
}
                                                              
