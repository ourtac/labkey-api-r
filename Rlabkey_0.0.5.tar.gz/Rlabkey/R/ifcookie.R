ifcookie <- function()
{exists("labkey.sessionCookieName")}
