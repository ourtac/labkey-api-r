### Name: labkey.updateRows
### Title: Update existing rows of data in a labkey database
### Aliases: labkey.updateRows
### Keywords: IO

### ** Examples


### Retrieve data from the database
#getdata <- labkey.selectRows(  baseUrl="https://www.labkey.org", 
#                                                               folderPath="/home/Study/demo", 
#                                                               schemaName="study", 
#                                                               queryName="Demographics")
#
### Modify the data
#modifyDat <- getdata[2,]
#modifyDat$City <- "Tacoma"
#
### Will need lsid for rows
### Update the rows in the database with the modified data
#labkey.updateRows(     baseUrl="https://www.labkey.org", 
#                                       folderPath="/home/Study/demo", 
#                                       schemaName="study", 
#                                       queryName="HIV Test Results", 
#                                       toUpdate=modifyDat)
#
#



