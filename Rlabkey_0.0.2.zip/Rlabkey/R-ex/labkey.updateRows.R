### Name: labkey.updateRows
### Title: Update existing rows of data in a labkey database
### Aliases: labkey.updateRows
### Keywords: IO

### ** Examples


# Examples to be updated when labkey.org has 8.3
## Update a single row of data
#newrow=data.frame(ParticipantId=249318596,,'09-Aug-06'), MVcomm=c('y','y'), MVswitch=c(88,99), stringsAsFactors=FALSE)

#labkey.updateRows(baseUrl="https://www.labkey.org", folderPath="/home/Study/demo", schemaName="study", queryName="HIV Test Results", toUpdate=newrow)





