### Name: labkey.insertRows
### Title: Insert new rows of data into a labkey database
### Aliases: labkey.insertRows
### Keywords: IO

### ** Examples

# Example to be modified when 8.3 is on labkey.org
# Insert some data:
#mydf <- data.frame(SequenceNum=c(2,3), lsid=c("URG345","URG346"), participantId=c(5055, 5056), stringsAsFactors=FALSE)

#mydata <- labkey.insertRows(baseUrl="https://www.labkey.org", folderPath="/home/Study/demo", schemaName="study", queryName="HIV Test Results, toInsert=mydf)





