### Name: labkey.insertRows
### Title: Insert new rows of data into a labkey database
### Aliases: labkey.insertRows
### Keywords: IO

### ** Examples

# Example to be modified when 8.3 is on labkey.org
# Insert two rows of data:
#newrows <- data.frame(participantID=c(24932540, 24932541), SequenceNum=c(2,3), age=c(40, 25), 
#height=c(70,65), gender=c("m","f"), city=c("Boston","New York"), state=c("MA","NY"), 
#country=c("USA","USA"), stringsAsFactors=FALSE)

#labkey.insertRows(baseUrl="https://www.labkey.org", folderPath="/home/Study/demo", 
#schemaName="study", queryName="Demographics", toInsert=newrows)





