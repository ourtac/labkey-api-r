### Name: labkey.deleteRows
### Title: Delete rows of data in a labkey database
### Aliases: labkey.deleteRows
### Keywords: IO

### ** Examples

# Examples to be updated when labkey.org has 8.3

## Delete two rows of data
#delrows <- data.frame(lsid=c('urn:lsid:labkey.org:****','urn:lsid:labkey.org:****',
#'urn:lsid:labkey.org.****'),stringsAsFactors=FALSE))

#labkey.deleteRows(baseUrl="https://www.labkey.org", folderPath="/home/Study/demo", 
#schemaName="study", queryName="HIV Test Results", toDelete=delrows)




