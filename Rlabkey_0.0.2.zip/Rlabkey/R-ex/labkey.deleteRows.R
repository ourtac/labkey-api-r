### Name: labkey.deleteRows
### Title: Delete rows of data in a labkey database
### Aliases: labkey.deleteRows
### Keywords: IO

### ** Examples

# Examples to be updated when labkey.org has 8.3
#mydf <- data.frame(lsid=c('urn:lsid:labkey.org:****','urn:lsid:labkey.org:****','urn:lsid:labkey.org.****'),stringsAsFactors=FALSE))

#mydata <- labkey.deleteRows(baseUrl="https://www.labkey.org", folderPath="/home/Study/demo", schemaName="study", queryName="HIV Test Results", toDelete=mydf)




