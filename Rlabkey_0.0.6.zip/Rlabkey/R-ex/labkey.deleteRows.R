### Name: labkey.deleteRows
### Title: Delete rows of data from a labkey database
### Aliases: labkey.deleteRows
### Keywords: IO

### ** Examples

## Insert, update and delete
# Note that users must have the necessary permissions in the database
# to be able to modify data through the use of these functions

### Not run
#newrow <- data.frame(name="Frank", age=11, stringsAsFactors=FALSE)
#labkey.insertRows(
#baseUrl="https://atlas-test.scharp.org/cpas", 
#folderPath="/CHAVI/Analysis/vobencha", 
#schemaName="lists", 
#queryName="testlist", 
#toInsert=newrow)
#
#updaterow=data.frame(Key=4,name="Patty",age=11, stringsAsFactors=FALSE)
#mydata <- labkey.updateRows(
#baseUrl="https://atlas-test.scharp.org/cpas", 
#folderPath="/CHAVI/Analysis/vobencha", 
#schemaName="lists", 
#queryName="testlist", 
#toUpdate=updaterow)
#
#deleterow <- data.frame(Key=1, stringsAsFactors=FALSE)
#mydata <- labkey.deleteRows(
#baseUrl="https://atlas-test.scharp.org/cpas", 
#folderPath="/CHAVI/Analysis/vobencha", 
#schemaName="lists", 
#queryName="testlist", 
#toDelete=deleterow)




