### R code from vignette source 'RlabkeyExample.Rnw'

